package com.nebulia.game;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.content.SharedPreferences;
import java.util.*;

public class MainActivity extends Activity {
    GameView game;
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(14,17,35)); getWindow().setNavigationBarColor(Color.rgb(14,17,35)); game = new GameView(this); setContentView(game); }
    @Override protected void onPause() { super.onPause(); if(game!=null) game.save(); }

    class GameView extends View {
        Paint p = new Paint(3); Canvas c; float sx, sy; String page="Деревня"; int crystals, gold, level, energy, shards;
        SharedPreferences prefs; RectF[] tabs = new RectF[5]; RectF action = new RectF(); String notice="Добро пожаловать домой, Путник!";
        int bg=Color.rgb(14,17,35), panel=Color.rgb(29,34,62), purple=Color.rgb(126,92,255), cyan=Color.rgb(95,224,238), white=Color.rgb(245,245,255);
        GameView(Context ctx) { super(ctx); prefs=getSharedPreferences("nebulia_save",0); crystals=prefs.getInt("crystals",120); gold=prefs.getInt("gold",500); level=prefs.getInt("level",1); energy=prefs.getInt("energy",20); shards=prefs.getInt("shards",0); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        void save(){prefs.edit().putInt("crystals",crystals).putInt("gold",gold).putInt("level",level).putInt("energy",energy).putInt("shards",shards).apply();}
        void rect(float l,float t,float r,float b,int color,float rad){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,rad,rad,p);}
        void text(String s,float x,float y,float size,int color,boolean bold){p.setColor(color);p.setTextSize(size);p.setTypeface(bold?Typeface.create("sans-serif",Typeface.BOLD):Typeface.create("sans-serif",Typeface.NORMAL));p.setShadowLayer(0,0,0,Color.TRANSPARENT); c.drawText(s,x,y,p);}
        void centered(String s,float x,float y,float size,int color,boolean bold){p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif",bold?1:0));text(s,x-p.measureText(s)/2,y,size,color,bold);}
        @Override protected void onDraw(Canvas canvas) {
            c=canvas; sx=getWidth()/360f; sy=getHeight()/800f; c.save(); c.scale(sx,sy); c.drawColor(bg);
            // ambient stars
            for(int i=0;i<48;i++){float x=(i*73%353)+3,y=(i*137%560)+15;p.setColor(Color.argb(65+(i%3)*40,180,190,255));c.drawCircle(x,y,(i%4==0)?1.7f:0.8f,p);}
            text("✦ NEBULIA",20,34,21,white,true); text("ЭХО ДРУГОГО МИРА",20,52,9,cyan,true);
            rect(211,14,340,46,panel,16); text("✧ "+crystals,224,34,13,cyan,true); text("◈ "+gold,285,34,13,white,true);
            if(page.equals("Деревня")) drawVillage(); else if(page.equals("Герои")) drawHeroes(); else if(page.equals("Задания")) drawQuests(); else if(page.equals("Призыв")) drawSummon(); else drawBattle();
            // navigation
            String[] labels={"Деревня","Герои","Задания","Призыв","Бой"}; String[] icons={"⌂","♙","☷","✧","⚔"};
            rect(9,710,351,787,Color.rgb(24,28,51),23);
            for(int i=0;i<5;i++){float x=9+i*68.4f; tabs[i]=new RectF(x,714,x+68,783); boolean selected=page.equals(labels[i]); if(selected) rect(x+4,719,x+64,778,Color.rgb(53,48,95),17); centered(icons[i],x+34,746,22,selected?cyan:Color.LTGRAY,true); centered(labels[i],x+34,766,selected?10:9,selected?white:Color.LTGRAY,selected);}
            c.restore();
        }
        void header(String title,String sub){text(title,20,91,24,white,true);text(sub,20,112,11,Color.rgb(175,185,220),false);}
        void drawVillage(){
            header("Тихая гавань","Твоя деревня • Уровень "+level);
            // fantasy landscape illustration
            rect(16,132,344,383,Color.rgb(28,47,72),22);
            p.setShader(new LinearGradient(0,135,0,383,Color.rgb(52,72,120),Color.rgb(30,75,80),Shader.TileMode.CLAMP));c.drawRoundRect(16,132,344,383,22,22,p);p.setShader(null);
            p.setColor(Color.rgb(222,217,255));c.drawCircle(276,176,24,p);p.setColor(Color.rgb(52,72,120));c.drawCircle(286,168,22,p);
            // mountains and glowing lake
            Path path=new Path();path.moveTo(16,305);path.lineTo(82,207);path.lineTo(124,269);path.lineTo(177,195);path.lineTo(244,290);path.lineTo(300,224);path.lineTo(344,282);path.lineTo(344,383);path.lineTo(16,383);path.close();p.setColor(Color.rgb(43,61,94));c.drawPath(path,p);
            rect(35,319,326,356,Color.rgb(52,137,150),16);
            // central cottage
            rect(119,254,231,325,Color.rgb(235,210,166),8);Path roof=new Path();roof.moveTo(106,261);roof.lineTo(175,211);roof.lineTo(244,261);roof.close();p.setColor(Color.rgb(110,79,145));c.drawPath(roof,p);
            rect(158,283,191,325,Color.rgb(73,54,80),4);rect(131,270,151,290,cyan,4);rect(199,270,219,290,cyan,4);
            for(int i=0;i<5;i++){p.setColor(Color.rgb(46,107,70));c.drawCircle(42+i*61,312+(i%2)*9,15,p);p.setColor(Color.rgb(75,150,93));c.drawCircle(42+i*61,306+(i%2)*9,12,p);}
            centered("✦",175,193,22,cyan,true);
            text("Сердце деревни",28,407,16,white,true);text("Восстанови осколки и верни свет миру.",28,426,11,Color.LTGRAY,false);
            rect(18,444,342,512,panel,16);text("✿  Уровень поселения",31,469,13,white,true);text("Уровень "+level+"  •  "+(level*250)+" золота для улучшения",31,490,10,Color.LTGRAY,false);
            rect(18,524,342,578,purple,16);centered("УЛУЧШИТЬ ДЕРЕВНЮ  ·  250 ◈",180,557,13,white,true);action.set(18,524,342,578);
            rect(18,590,342,674,panel,16);text("Путевой дневник",31,615,14,white,true);text(notice,31,638,10,cyan,false);text("Энергия: "+energy+" / 20     Осколки: "+shards,31,659,11,Color.LTGRAY,false);
        }
        void drawHeroes(){
            header("Твои спутники","Они помогут раскрыть тайны Астериона");
            String[][] hs={{"Лиора","Хранительница леса","✿","Редкая"},{"Каэль","Картограф разломов","✦","Эпический"},{"Мэйри","Дух-лисица","❋","Редкая"},{"Селестра","Рыцарь рассвета","⚔","Эпический"}};
            for(int i=0;i<4;i++){int y=139+i*130;rect(18,y,342,y+112,panel,17);rect(29,y+12,91,y+100,Color.rgb(52+i*8,48,91+i*10),14);centered(hs[i][2],60,y+66,34,cyan,true);text(hs[i][0],105,y+33,17,white,true);text(hs[i][1],105,y+54,10,Color.LTGRAY,false);text(hs[i][3]+"  •  Ур. "+level,105,y+76,11,purple,true);text("Сила "+(120+level*27+i*13),105,y+94,10,cyan,false);}
        }
        void drawQuests(){
            header("Задания","Каждый шаг приближает тебя к разгадке");
            String[][] qs={{"Первый рассвет","Посети свою деревню","+ 100 золота"},{"Сила единства","Открой список героев","+ 30 кристаллов"},{"Зов разлома","Победи в тренировочном бою","+ 1 осколок"}};
            for(int i=0;i<3;i++){int y=145+i*145;rect(18,y,342,y+122,panel,17);text("ГЛАВА 1  ·  ЗАДАНИЕ 0"+(i+1),31,y+25,9,cyan,true);text(qs[i][0],31,y+51,17,white,true);text(qs[i][1],31,y+73,11,Color.LTGRAY,false);text("НАГРАДА  "+qs[i][2],31,y+98,11,purple,true);rect(250,y+78,327,y+108,purple,11);centered("ЗАБРАТЬ",288,y+98,10,white,true);}
            text("Подсказка: нажми «Забрать», чтобы получить награду.",20,615,10,Color.LTGRAY,false);
        }
        void drawSummon(){
            header("Звёздный призыв","Позови героя из-за грани миров");
            rect(18,139,342,438,Color.rgb(38,34,78),23);
            p.setShader(new RadialGradient(180,272,135,new int[]{Color.rgb(132,92,255),Color.rgb(61,47,121),Color.rgb(35,32,70)},null,Shader.TileMode.CLAMP));c.drawRoundRect(18,139,342,438,23,23,p);p.setShader(null);
            for(int i=0;i<16;i++){float a=i*0.9f;float x=180+(float)Math.cos(a)*((i%5)*21+22),y=274+(float)Math.sin(a)*((i%5)*19+22);p.setColor(Color.argb(180,190,220,255));c.drawCircle(x,y,2+(i%2),p);}
            centered("✧",180,285,83,white,true);centered("ВОРОТА АСТЕРИОНА",180,357,14,white,true);centered("Каждый призыв — новая история",180,381,10,Color.LTGRAY,false);
            text("Кристаллы: "+crystals,25,469,13,cyan,true);
            rect(18,492,342,550,purple,16);centered("ПРИЗВАТЬ 1 РАЗ  ·  80 ✧",180,527,13,white,true);action.set(18,492,342,550);
            rect(18,562,342,620,panel,16);centered("ПРИЗВАТЬ 10 РАЗ  ·  720 ✧",180,597,13,white,true);
            text("Герои сохраняются в твоей коллекции.",24,650,10,Color.LTGRAY,false);
        }
        void drawBattle(){
            header("Тренировочный бой","Испытай силу команды в разломе");
            rect(18,139,342,402,Color.rgb(39,40,80),22);
            centered("✦",180,229,68,cyan,true);centered("РАЗЛОМ № 001",180,270,17,white,true);centered("Тени древнего леса",180,293,12,Color.LTGRAY,false);
            rect(35,318,325,334,Color.rgb(60,63,95),8);rect(35,318,Math.min(325,35+energy*14.5f),334,cyan,8);
            centered("Энергия: "+energy+" / 20",180,357,11,white,false);
            text("Награды за победу",25,438,15,white,true);
            rect(18,455,342,508,panel,14);text("◈  + 120 золота",32,479,13,white,true);text("✧  + 15 кристаллов",32,498,13,cyan,true);
            rect(18,529,342,590,purple,16);centered("НАЧАТЬ СРАЖЕНИЕ",180,566,14,white,true);action.set(18,529,342,590);
            text("Пошаговая авто-битва • Награды за победу",23,617,10,Color.LTGRAY,false);
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX()/sx,y=e.getY()/sy;
            for(int i=0;i<5;i++)if(tabs[i]!=null&&tabs[i].contains(x,y)){page=new String[]{"Деревня","Герои","Задания","Призыв","Бой"}[i];invalidate();return true;}
            if(action.contains(x,y)){
                if(page.equals("Деревня")){if(gold>=250){gold-=250;level++;notice="Деревня улучшена! Новый уровень: "+level; }else notice="Недостаточно золота. Выполни задание!";}
                else if(page.equals("Призыв")){if(crystals>=80){crystals-=80;shards++;notice="";page="Герои";Toast.makeText(MainActivity.this,"Новый герой присоединился! (прототип)",Toast.LENGTH_SHORT).show();}else Toast.makeText(MainActivity.this,"Нужно 80 кристаллов",Toast.LENGTH_SHORT).show();}
                else if(page.equals("Бой")){if(energy>0){energy--;gold+=120;crystals+=15;shards++;Toast.makeText(MainActivity.this,"Победа! +120 золота, +15 кристаллов",Toast.LENGTH_SHORT).show();}else Toast.makeText(MainActivity.this,"Энергия закончилась",Toast.LENGTH_SHORT).show();}
                save();invalidate();return true;
            }
            if(page.equals("Задания")){if(y>145&&y<600){int i=Math.min(2,Math.max(0,(int)((y-145)/145)));if(i==0)gold+=100;else if(i==1)crystals+=30;else shards++;notice="Награда получена!";save();invalidate();Toast.makeText(MainActivity.this,"Награда получена",Toast.LENGTH_SHORT).show();return true;}}
            if(page.equals("Призыв")&&y>562&&y<620){if(crystals>=720){crystals-=720;shards+=10;page="Герои";save();invalidate();}else Toast.makeText(MainActivity.this,"Нужно 720 кристаллов",Toast.LENGTH_SHORT).show();}
            return true;
        }
    }
}
